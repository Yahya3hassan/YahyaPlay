import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Download, Search, Star, Users, Gamepad2, TrendingUp, Clock, Shield } from "lucide-react"

const games = [
  {
    id: 1,
    title: "Cyberpunk 2077",
    description: "لعبة أكشن وRPG في عالم مستقبلي مفتوح",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.5,
    downloads: "2.5M",
    size: "70 GB",
    category: "أكشن",
    featured: true,
  },
  {
    id: 2,
    title: "FIFA 24",
    description: "أحدث إصدار من سلسلة ألعاب كرة القدم الشهيرة",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.8,
    downloads: "5.2M",
    size: "45 GB",
    category: "رياضة",
    featured: true,
  },
  {
    id: 3,
    title: "Call of Duty: Modern Warfare",
    description: "لعبة إطلاق نار من منظور الشخص الأول",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.6,
    downloads: "8.1M",
    size: "85 GB",
    category: "أكشن",
    featured: false,
  },
  {
    id: 4,
    title: "Minecraft",
    description: "لعبة بناء وإبداع في عالم مفتوح",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.9,
    downloads: "15.3M",
    size: "2 GB",
    category: "إبداع",
    featured: true,
  },
  {
    id: 5,
    title: "Grand Theft Auto V",
    description: "لعبة أكشن ومغامرات في عالم مفتوح",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.7,
    downloads: "12.8M",
    size: "95 GB",
    category: "أكشن",
    featured: false,
  },
  {
    id: 6,
    title: "Fortnite",
    description: "لعبة باتل رويال مجانية ومثيرة",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.4,
    downloads: "20.5M",
    size: "30 GB",
    category: "باتل رويال",
    featured: true,
  },
  {
    id: 7,
    title: "The Witcher 3",
    description: "لعبة RPG ملحمية في عالم خيالي",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.8,
    downloads: "6.7M",
    size: "50 GB",
    category: "RPG",
    featured: false,
  },
  {
    id: 8,
    title: "Valorant",
    description: "لعبة إطلاق نار تكتيكية من منظور الشخص الأول",
    image: "/placeholder.svg?height=200&width=300",
    rating: 4.5,
    downloads: "9.2M",
    size: "25 GB",
    category: "أكشن",
    featured: false,
  },
]

const categories = ["الكل", "أكشن", "رياضة", "إبداع", "RPG", "باتل رويال"]

export default function YahyaPlayHomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Gamepad2 className="h-8 w-8 text-purple-400" />
                <h1 className="text-2xl font-bold text-white">YahyaPlay</h1>
              </div>
            </div>
            <nav className="hidden md:flex items-center space-x-6 rtl:space-x-reverse">
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                الرئيسية
              </a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                الألعاب
              </a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                الأحدث
              </a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                الأكثر تحميلاً
              </a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                اتصل بنا
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-white mb-6">أفضل موقع لتحميل الألعاب</h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            اكتشف وحمل أحدث وأفضل الألعاب مجاناً. آلاف الألعاب في انتظارك!
          </p>
          <div className="flex justify-center max-w-md mx-auto">
            <div className="relative w-full">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-5 w-5" />
              <Input
                placeholder="ابحث عن لعبتك المفضلة..."
                className="pr-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-400"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-slate-800/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="flex flex-col items-center">
              <Download className="h-8 w-8 text-purple-400 mb-2" />
              <div className="text-2xl font-bold text-white">50M+</div>
              <div className="text-slate-400">تحميل</div>
            </div>
            <div className="flex flex-col items-center">
              <Gamepad2 className="h-8 w-8 text-purple-400 mb-2" />
              <div className="text-2xl font-bold text-white">10K+</div>
              <div className="text-slate-400">لعبة</div>
            </div>
            <div className="flex flex-col items-center">
              <Users className="h-8 w-8 text-purple-400 mb-2" />
              <div className="text-2xl font-bold text-white">2M+</div>
              <div className="text-slate-400">مستخدم</div>
            </div>
            <div className="flex flex-col items-center">
              <Shield className="h-8 w-8 text-purple-400 mb-2" />
              <div className="text-2xl font-bold text-white">100%</div>
              <div className="text-slate-400">آمن</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Games */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-3xl font-bold text-white flex items-center">
              <TrendingUp className="h-8 w-8 text-purple-400 ml-3" />
              الألعاب المميزة
            </h3>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map((category) => (
              <Button
                key={category}
                variant={category === "الكل" ? "default" : "outline"}
                className={
                  category === "الكل"
                    ? "bg-purple-600 hover:bg-purple-700"
                    : "border-slate-600 text-slate-300 hover:bg-slate-800"
                }
              >
                {category}
              </Button>
            ))}
          </div>

          {/* Games Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {games.map((game) => (
              <Card
                key={game.id}
                className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-all duration-300 hover:scale-105"
              >
                <CardHeader className="p-0">
                  <div className="relative">
                    <img
                      src={game.image || "/placeholder.svg"}
                      alt={game.title}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    {game.featured && <Badge className="absolute top-2 right-2 bg-purple-600">مميز</Badge>}
                    <Badge className="absolute top-2 left-2 bg-slate-900/80">{game.category}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <CardTitle className="text-white mb-2 text-lg">{game.title}</CardTitle>
                  <CardDescription className="text-slate-400 mb-4 line-clamp-2">{game.description}</CardDescription>

                  <div className="flex items-center justify-between text-sm text-slate-400 mb-4">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 ml-1" />
                      <span>{game.rating}</span>
                    </div>
                    <div className="flex items-center">
                      <Download className="h-4 w-4 ml-1" />
                      <span>{game.downloads}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 ml-1" />
                      <span>{game.size}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">
                    <Download className="h-4 w-4 ml-2" />
                    تحميل مجاني
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 rtl:space-x-reverse mb-4">
                <Gamepad2 className="h-6 w-6 text-purple-400" />
                <h4 className="text-xl font-bold text-white">YahyaPlay</h4>
              </div>
              <p className="text-slate-400">أفضل موقع لتحميل الألعاب المجانية والآمنة</p>
            </div>
            <div>
              <h5 className="text-white font-semibold mb-4">روابط سريعة</h5>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    الرئيسية
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    الألعاب
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    الأحدث
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    الأكثر تحميلاً
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="text-white font-semibold mb-4">الفئات</h5>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    ألعاب الأكشن
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    ألعاب الرياضة
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    ألعاب الإبداع
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    ألعاب RPG
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="text-white font-semibold mb-4">تواصل معنا</h5>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    اتصل بنا
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    الدعم الفني
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    سياسة الخصوصية
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    شروط الاستخدام
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2024 YahyaPlay. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
